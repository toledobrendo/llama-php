<?php
  define('DB_HOST', '127.0.0.1:3306');
  define('DB_USERNAME', 'student');
  define('DB_PASSWORD','123qwe');
  define('DB_NAME','php_lesson_db');
 ?>
